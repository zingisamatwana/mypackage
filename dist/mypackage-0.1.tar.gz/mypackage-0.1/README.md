# mypackage
This library is created as an example of learning how to publish my own Python package
## building this package locally
`python setup.py sdist`

## installing this package from Github

`pip install git+`

## updating this package from Github
 `pip install --upgrade git+`
